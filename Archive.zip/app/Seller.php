<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seller extends Model
{

  protected $with = ['user', 'user.shop'];

  public function user(){
  	return $this->belongsTo(User::class);
  }

  public function payments(){
  	return $this->hasMany(Payment::class);
  }
}
