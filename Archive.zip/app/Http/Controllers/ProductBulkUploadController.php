<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\SubCategory;
use App\SubSubCategory;
use App\Brand;
use App\User;
use Auth;
use App\ProductsImport;
use App\ProductsLink;
use App\ProductsExport;
use PDF;
use Excel;
use Illuminate\Support\Str;

class ProductBulkUploadController extends Controller
{
    public function index()
    {
        return view('backend.product.bulk_upload.index');
    }


    public function knobby_category()
    {
        return view('backend.product.bulk_upload.knobby_category');
    }

    public function knobby_bike_fitment()
    {
        return view('backend.product.bulk_upload.knobby_bike_fitment');
    }

    public function knobby_product()
    {
        return view('backend.product.bulk_upload.knobby_product');
    }



    public function product_link()
    {
        // $products = Product::with(['categories'])->orderBy('created_at', 'desc')->get();

        $topLevelNodes = Category::where('parent_id', 0)->where('published', 1)->get();
        return view('backend.product.bulk_upload.link', compact('topLevelNodes'));
    }

    public function export()
    {
        return Excel::download(new ProductsExport, 'products.xlsx');
    }

    // public function pdf_download_category()
    // {
    //     $categories = Category::all();

    //     return PDF::loadView('backend.downloads.category', [
    //         'categories' => $categories,
    //     ], [], [])->download('category.pdf');
    // }

    // public function pdf_download_brand()
    // {
    //     $brands = Brand::all();

    //     return PDF::loadView('backend.downloads.brand', [
    //         'brands' => $brands,
    //     ], [], [])->download('brands.pdf');
    // }

    // public function pdf_download_seller()
    // {
    //     $users = User::where('user_type', 'seller')->get();

    //     return PDF::loadView('backend.downloads.user', [
    //         'users' => $users,
    //     ], [], [])->download('user.pdf');
    // }

    public function bulk_upload(Request $request)
    {
        if ($request->hasFile('bulk_file')) {
            $import = new ProductsImport;

            Excel::import($import, request()->file('bulk_file'));
        }
        return back();
    }


    public function bulk_link(Request $request)
    {
        $productIds = explode(',', $request->input('selectedCategories_product_id'));
        if ($request->hasFile('bulk_file')) {
            $import = new ProductsLink($productIds);

            Excel::import($import, request()->file('bulk_file'));
        }
        return back();
    }
}
